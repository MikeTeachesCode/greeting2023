from .greeting2023 import Greeting

def main():
    g = Greeting()
    def init_app():

        g.init_app()

    def welcome():

        g.welcome()

    def menu():
        g.menu()

if __name__ == "__main__":
    main()
