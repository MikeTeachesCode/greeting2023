# README.md

- This is a super simple greeting module for Python.